<?php
session_start();
include 'conexion.php';

if ($_SESSION['rol'] != 'admin') {
    die("Acceso denegado");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo "Usuario eliminado correctamente.";
    } else {
        echo "Error al eliminar usuario.";
    }
    $stmt->close();
}
?>

<form method="POST">
    ID del usuario a eliminar: <input type="number" name="id" required><br>
    <input type="submit" value="Eliminar Usuario">
</form>
