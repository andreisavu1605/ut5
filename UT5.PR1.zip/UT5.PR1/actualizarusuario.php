<?php
session_start();
include 'conexion.php';

if ($_SESSION['rol'] != 'admin') {
    die("Acceso denegado");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nuevo_usuario = $_POST['nombre_usuario'];
    $nuevo_password = $_POST['password'];

    $stmt = $conn->prepare("UPDATE usuarios SET nombre_usuario = ?, password = ? WHERE id = ?");
    $stmt->bind_param("ssi", $nuevo_usuario, $nuevo_password, $id);
    
    if ($stmt->execute()) {
        echo "Usuario actualizado correctamente.";
    } else {
        echo "Error al actualizar usuario.";
    }
    $stmt->close();
}
?>

<form method="POST">
    ID del usuario: <input type="number" name="id" required><br>
    Nuevo Usuario: <input type="text" name="nombre_usuario" required><br>
    Nueva Contraseña: <input type="password" name="password" required><br>
    <input type="submit" value="Actualizar Usuario">
</form>
