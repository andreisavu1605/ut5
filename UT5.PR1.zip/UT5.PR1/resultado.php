<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

echo "Bienvenido, " . $_SESSION['nombre_usuario'] . "<br>";
echo "Tu ID es: " . $_SESSION['id'] . "<br>";
echo "Rol: " . $_SESSION['rol'] . "<br>";
echo "<a href='menu.php'>Ir al menú</a> | <a href='logout.php'>Cerrar sesión</a>";
?>
