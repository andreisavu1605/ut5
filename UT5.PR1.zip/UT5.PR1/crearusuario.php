<?php
session_start();
include 'conexion.php';

if ($_SESSION['rol'] != 'admin') {
    die("Acceso denegado");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['nombre_usuario'];
    $password = $_POST['password'];
    $rol = $_POST['rol'];

    $stmt = $conn->prepare("INSERT INTO usuarios (nombre_usuario, password, rol) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $usuario, $password, $rol);
    
    if ($stmt->execute()) {
        echo "Usuario creado correctamente.";
    } else {
        echo "Error al crear usuario.";
    }
    $stmt->close();
}
?>

<form method="POST">
    Usuario: <input type="text" name="nombre_usuario" required><br>
    Contraseña: <input type="password" name="password" required><br>
    Rol: 
    <select name="rol">
        <option value="admin">Admin</option>
        <option value="estandar" selected>Estándar</option>
    </select><br>
    <input type="submit" value="Crear Usuario">
</form>
