<?php
session_start();
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['nombre_usuario'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, nombre_usuario, rol FROM usuarios WHERE nombre_usuario = ? AND password = ?");
    $stmt->bind_param("ss", $usuario, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $nombre_usuario, $rol);
        $stmt->fetch();
        $_SESSION['id'] = $id;
        $_SESSION['nombre_usuario'] = $nombre_usuario;
        $_SESSION['rol'] = $rol;
        header("Location: resultado.php");
    } else {
        echo "Credenciales incorrectas.";
    }
    $stmt->close();
}
?>

<form method="POST">
    Usuario: <input type="text" name="nombre_usuario" required><br>
    Contraseña: <input type="password" name="password" required><br>
    <input type="submit" value="Iniciar sesión">
</form>
