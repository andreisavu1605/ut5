<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

echo "<h2>Menú Principal</h2>";
if ($_SESSION['rol'] == 'admin') {
    echo "<a href='crear_usuario.php'>Crear Usuario</a><br>";
    echo "<a href='actualizar_usuario.php'>Actualizar Usuario</a><br>";
    echo "<a href='borrar_usuario.php'>Borrar Usuario</a><br>";
    echo "<a href='listar_usuarios.php'>Listar Usuarios</a><br>";
} else {
    echo "<a href='resultado.php'>Ver mis datos</a><br>";
}

echo "<a href='logout.php'>Cerrar sesión</a>";
?>
